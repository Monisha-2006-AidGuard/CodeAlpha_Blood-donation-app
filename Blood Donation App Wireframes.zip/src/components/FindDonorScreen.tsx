interface FindDonorScreenProps {
  onBack: () => void;
  onSelectDonor: () => void;
}

const mockDonors = [
  { id: 1, name: 'John Doe', bloodGroup: 'A+' },
  { id: 2, name: 'Jane Smith', bloodGroup: 'O+' },
  { id: 3, name: 'Mike Johnson', bloodGroup: 'B+' },
  { id: 4, name: 'Sarah Williams', bloodGroup: 'AB+' },
  { id: 5, name: 'Tom Brown', bloodGroup: 'O-' },
];

export function FindDonorScreen({ onBack, onSelectDonor }: FindDonorScreenProps) {
  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="flex items-center p-4 border-b-2 border-gray-300">
        <button onClick={onBack} className="text-black mr-4">
          &lt; Back
        </button>
        <h2 className="text-black">Find Donor</h2>
      </div>
      
      {/* Search Bar */}
      <div className="p-4">
        <div className="w-full h-12 bg-white border-2 border-gray-400 flex items-center px-4">
          <span className="text-gray-500">Search</span>
        </div>
      </div>
      
      {/* Donor List */}
      <div className="flex-1 overflow-y-auto px-4">
        {mockDonors.map((donor) => (
          <div
            key={donor.id}
            className="flex items-center gap-4 p-4 border-2 border-gray-300 mb-3 bg-white"
          >
            <div className="w-12 h-12 rounded-full bg-gray-400 border-2 border-gray-600 flex-shrink-0" />
            
            <div className="flex-1">
              <div className="h-4 bg-gray-300 mb-2 w-32" />
              <div className="h-4 bg-gray-300 w-16" />
            </div>
            
            <button
              onClick={onSelectDonor}
              className="px-6 py-2 bg-black text-white border-2 border-black"
            >
              Contact
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}