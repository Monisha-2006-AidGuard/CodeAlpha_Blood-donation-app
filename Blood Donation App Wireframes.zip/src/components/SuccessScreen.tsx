interface SuccessScreenProps {
  onHome: () => void;
}

export function SuccessScreen({ onHome }: SuccessScreenProps) {
  return (
    <div className="h-full flex flex-col items-center justify-center p-8 bg-white">
      <div className="mb-12">
        <div className="w-32 h-32 rounded-full bg-gray-300 border-4 border-black flex items-center justify-center mb-8">
          <svg
            className="w-16 h-16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="black"
            strokeWidth="3"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </div>
        
        <div className="space-y-4 text-center">
          <div className="h-6 bg-gray-300 w-64 mx-auto" />
          <div className="h-6 bg-gray-300 w-48 mx-auto" />
        </div>
      </div>
      
      <button
        onClick={onHome}
        className="w-full h-14 bg-black text-white border-2 border-black"
      >
        Home
      </button>
    </div>
  );
}
