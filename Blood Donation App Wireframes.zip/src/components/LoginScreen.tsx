interface LoginScreenProps {
  onLogin: () => void;
  onSignUp: () => void;
}

export function LoginScreen({ onLogin, onSignUp }: LoginScreenProps) {
  return (
    <div className="h-full flex flex-col items-center justify-center p-8 bg-white">
      <div className="w-full">
        <h2 className="text-black mb-12 text-center">Login</h2>
        
        <div className="space-y-4 mb-8">
          <div className="w-full h-12 bg-white border-2 border-gray-400 flex items-center px-4">
            <span className="text-gray-500">Email/Phone</span>
          </div>
          
          <div className="w-full h-12 bg-white border-2 border-gray-400 flex items-center px-4">
            <span className="text-gray-500">Password</span>
          </div>
        </div>
        
        <button
          onClick={onLogin}
          className="w-full h-14 bg-black text-white border-2 border-black mb-4"
        >
          Login
        </button>
        
        <button
          onClick={onSignUp}
          className="text-gray-600 underline w-full text-center"
        >
          Sign up
        </button>
      </div>
    </div>
  );
}
