import { useState } from 'react';

interface DonorProfileScreenProps {
  onBack: () => void;
  onContact: () => void;
}

export function DonorProfileScreen({ onBack, onContact }: DonorProfileScreenProps) {
  const [isAvailable, setIsAvailable] = useState(true);

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="flex items-center p-4 border-b-2 border-gray-300">
        <button onClick={onBack} className="text-black mr-4">
          &lt; Back
        </button>
        <h2 className="text-black">Donor Profile</h2>
      </div>
      
      {/* Profile Content */}
      <div className="flex-1 flex flex-col items-center p-8">
        <div className="w-32 h-32 rounded-full bg-gray-400 border-4 border-gray-600 mb-8" />
        
        <div className="w-full space-y-4 mb-8">
          <div className="h-6 bg-gray-300 w-48 mx-auto" />
          <div className="h-6 bg-gray-300 w-32 mx-auto" />
          <div className="h-6 bg-gray-300 w-56 mx-auto" />
        </div>
        
        <button
          onClick={onContact}
          className="w-full h-14 bg-black text-white border-2 border-black mb-6"
        >
          Contact
        </button>
        
        {/* Availability Toggle */}
        <div className="flex items-center justify-between w-full p-4 border-2 border-gray-400 bg-white">
          <span className="text-black">Availability</span>
          <button
            onClick={() => setIsAvailable(!isAvailable)}
            className={`w-16 h-8 border-2 border-black relative ${
              isAvailable ? 'bg-black' : 'bg-white'
            }`}
          >
            <div
              className={`absolute top-0.5 w-6 h-6 bg-gray-300 border border-black transition-all ${
                isAvailable ? 'right-0.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
}