interface HomeScreenProps {
  onNavigate: (screen: 'findDonor' | 'requestBlood' | 'home') => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  return (
    <div className="h-full flex flex-col bg-white">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-4 border-b-2 border-gray-300">
        <div className="w-10 h-10 rounded-full bg-gray-400 border-2 border-gray-600" />
        <h2 className="text-black">LifeSaver</h2>
        <div className="w-10" />
      </div>
      
      {/* Dashboard Grid */}
      <div className="flex-1 p-8">
        <div className="grid grid-cols-2 gap-6 mb-8">
          <button
            onClick={() => onNavigate('findDonor')}
            className="aspect-square bg-white border-4 border-black flex items-center justify-center"
          >
            <span className="text-black">Find Donor</span>
          </button>
          
          <button
            onClick={() => onNavigate('requestBlood')}
            className="aspect-square bg-white border-4 border-black flex items-center justify-center"
          >
            <span className="text-black">Request Blood</span>
          </button>
          
          <button className="aspect-square bg-white border-4 border-black flex items-center justify-center">
            <span className="text-black">Blood Banks</span>
          </button>
          
          <button className="aspect-square bg-white border-4 border-black flex items-center justify-center">
            <span className="text-black">Donations</span>
          </button>
        </div>
      </div>
      
      {/* Floating SOS Button */}
      <button className="absolute bottom-8 right-8 w-16 h-16 rounded-full bg-black text-white border-4 border-black shadow-lg">
        SOS
      </button>
    </div>
  );
}
