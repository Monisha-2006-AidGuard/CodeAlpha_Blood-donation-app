interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  return (
    <div className="h-full flex flex-col items-center justify-between p-8 bg-white">
      <div className="flex-1 flex flex-col items-center justify-center w-full">
        <h1 className="text-black mb-4">LifeSaver</h1>
        
        <div className="w-full h-8 bg-gray-300 mb-8" />
        
        <div className="w-full aspect-square bg-gray-300 border-2 border-gray-400 flex items-center justify-center mb-8">
          <span className="text-gray-500">Illustration Placeholder</span>
        </div>
      </div>
      
      <button
        onClick={onGetStarted}
        className="w-full h-14 bg-black text-white border-2 border-black"
      >
        Get Started
      </button>
    </div>
  );
}
