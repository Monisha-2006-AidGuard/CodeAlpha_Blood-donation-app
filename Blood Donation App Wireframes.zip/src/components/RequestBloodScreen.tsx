interface RequestBloodScreenProps {
  onBack: () => void;
  onSubmit: () => void;
}

export function RequestBloodScreen({ onBack, onSubmit }: RequestBloodScreenProps) {
  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="flex items-center p-4 border-b-2 border-gray-300">
        <button onClick={onBack} className="text-black mr-4">
          &lt; Back
        </button>
        <h2 className="text-black">Request Blood</h2>
      </div>
      
      {/* Form */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="space-y-4 mb-8">
          <div>
            <div className="text-gray-600 mb-2">Patient Name</div>
            <div className="w-full h-12 bg-white border-2 border-gray-400" />
          </div>
          
          <div>
            <div className="text-gray-600 mb-2">Blood Group</div>
            <div className="w-full h-12 bg-white border-2 border-gray-400" />
          </div>
          
          <div>
            <div className="text-gray-600 mb-2">Units</div>
            <div className="w-full h-12 bg-white border-2 border-gray-400" />
          </div>
          
          <div>
            <div className="text-gray-600 mb-2">Location</div>
            <div className="w-full h-12 bg-white border-2 border-gray-400" />
          </div>
          
          <div>
            <div className="text-gray-600 mb-2">Date</div>
            <div className="w-full h-12 bg-white border-2 border-gray-400" />
          </div>
        </div>
        
        <button
          onClick={onSubmit}
          className="w-full h-14 bg-black text-white border-2 border-black"
        >
          Submit
        </button>
      </div>
    </div>
  );
}