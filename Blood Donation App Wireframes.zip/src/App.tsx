import { useState } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { LoginScreen } from './components/LoginScreen';
import { HomeScreen } from './components/HomeScreen';
import { FindDonorScreen } from './components/FindDonorScreen';
import { DonorProfileScreen } from './components/DonorProfileScreen';
import { RequestBloodScreen } from './components/RequestBloodScreen';
import { SuccessScreen } from './components/SuccessScreen';

type Screen = 'welcome' | 'login' | 'home' | 'findDonor' | 'donorProfile' | 'requestBlood' | 'success';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');

  const renderScreen = () => {
    switch (currentScreen) {
      case 'welcome':
        return <WelcomeScreen onGetStarted={() => setCurrentScreen('login')} />;
      case 'login':
        return <LoginScreen onLogin={() => setCurrentScreen('home')} onSignUp={() => setCurrentScreen('login')} />;
      case 'home':
        return <HomeScreen onNavigate={setCurrentScreen} />;
      case 'findDonor':
        return <FindDonorScreen onBack={() => setCurrentScreen('home')} onSelectDonor={() => setCurrentScreen('donorProfile')} />;
      case 'donorProfile':
        return <DonorProfileScreen onBack={() => setCurrentScreen('findDonor')} onContact={() => setCurrentScreen('success')} />;
      case 'requestBlood':
        return <RequestBloodScreen onBack={() => setCurrentScreen('home')} onSubmit={() => setCurrentScreen('success')} />;
      case 'success':
        return <SuccessScreen onHome={() => setCurrentScreen('home')} />;
      default:
        return <WelcomeScreen onGetStarted={() => setCurrentScreen('login')} />;
    }
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <div className="w-full max-w-md h-[800px] bg-gray-100 border-4 border-black rounded-lg overflow-hidden relative">
        {renderScreen()}
      </div>
    </div>
  );
}
